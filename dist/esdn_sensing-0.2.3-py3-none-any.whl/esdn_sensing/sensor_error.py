class SensorError(Exception):
    """Generic sensor related exception
    """
    pass