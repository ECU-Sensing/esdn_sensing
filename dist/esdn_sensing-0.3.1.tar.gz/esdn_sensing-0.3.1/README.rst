Welcome to ESDN_Sensing!
=======================================

.. image:: https://readthedocs.org/projects/esdn_sensing/badge/?version=latest
    :target: https://ecu-sensing.github.io/esdn_sensing/
    :alt: Documentation Status

.. image:: https://img.shields.io/badge/Project-ESDN%20Sensing-blueviolet
    :target: https://github.com/ECU-Sensing/esdn_sensing
    :alt: Project

.. image:: https://img.shields.io/badge/language-Python-blue
    :target: https://www.python.org/
    :alt: Language

.. include:: ../QUICKSTART.md
   :parser: myst_parser.sphinx_