Welcome to esdn_sensing!
=======================================

.. image:: https://readthedocs.org/projects/esdn_sensing/badge/?version=latest
    :target: https://docs.circuitpython.org/projects/esdn_sensing/en/latest/
    :alt: Documentation Status

.. image:: https://img.shields.io/badge/Project-ECU%20Sensing-blueviolet
    :target: https://github.com/esdn_sensing
    :alt: Project

.. image:: https://img.shields.io/badge/language-Python-blue
    :target: https://www.python.org/
    :alt: Language

